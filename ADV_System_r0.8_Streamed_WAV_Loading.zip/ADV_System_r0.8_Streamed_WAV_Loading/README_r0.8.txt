ADV System r0.8 — Streamed WAV loading fix

Based on r0.7. Replaced full-source WAV allocation with a 1024-byte sliding read window.
The source WAV is read in small SD chunks and converted directly into the final
16-bit / 16 kHz mono PCM buffer. Up to three seconds are retained per channel.

8-bit and 16-bit uncompressed PCM, mono or stereo, 8–48 kHz retained.
Existing Music, USB SD, DIAG, pattern save/load and controls unchanged.
Original WAV files are never modified.

A final output allocation is still required: up to 96 KB per three-second sample.
If there is not enough available contiguous PSRAM/internal memory, the firmware
can still report NOT ENOUGH MEMORY; this revision removes the large TEMPORARY
source allocation that previously caused failures for 48 kHz samples.

Build environment: ESP32 3.2.1; ESP8266Audio 2.4.3 with compatibility patch
as described in the included text file.

NOT compiled or tested on hardware. Back up r0.7 and v1.0.
