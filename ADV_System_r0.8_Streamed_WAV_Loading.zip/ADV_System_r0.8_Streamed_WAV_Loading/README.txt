ADV System r0.7 — WAV compatibility and pattern save/open
=======================================================
Changes from r0.6:
- WAV sample loader accepts standard uncompressed RIFF PCM, 8-bit or 16-bit,
  mono or stereo, sample rates 8,000 through 48,000 Hz.
- On loading, samples are converted in RAM to signed 16-bit, 16,000 Hz mono.
  Nearest-neighbor sample-rate conversion; no persistent converted files.
  The first three seconds are loaded; original WAVs are never modified.
- S in Sequencer saves the current pattern to a new, auto-numbered
  /Samples/Patterns/PAT_0001.pat, PAT_0002.pat, etc. Never overwrites.
- O opens a browser for saved .pat patterns. ;/. navigate, ENTER load,
  backtick cancel. Saved data: BPM, 4 sample paths, 4x16 step states.
- The firmware creates /Samples/Patterns on the SD card if missing.
- Existing SD USB export, Music, DIAG and sequencer audio mixer retained.

IMPORTANT KEY CHANGE: S now SAVES, so tempo UP moves from S to E.
W lowers BPM by 5; E raises BPM by 5. 40–240 BPM, default 120.

Patterns use a simple text format (ADVPAT1). No need to edit them manually.
Loading a pattern tries to reload its original WAV files from /Samples.
If a file has been moved/deleted, that channel will be empty until reassigned.

Known limitations:
- Not compiled or hardware tested. Retain your working r0.6.
- Nearest-neighbor resampling is quick but may sound rough on high-frequency
  sounds. 8-bit PCM WAV uses unsigned samples, as the WAV standard specifies.
- Loading four long stereo files may briefly use significant PSRAM.
- The sequencer audio engine is still experimental; timing and overlap
  need hardware verification.
- Auto-numbered pattern saving requires a writable SD card not owned by PC.

Build setup from working baseline: ESP32 3.2.1, ESP8266Audio 2.4.3
with one-line AudioOutputPDM.cpp compatibility edit (included).
