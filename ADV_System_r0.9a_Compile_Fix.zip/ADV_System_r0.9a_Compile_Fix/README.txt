ADV System r0.9a — compile fixes for r0.9

1. Moved SeqVoice structure into SeqVoice.h so Arduino sketch auto-generated function prototypes see its declaration.
2. Used std::min<int32_t> / std::max<int32_t> in the 32-bit audio mix clamp.

No intentional behavior changes from r0.9. SD streaming is still experimental.

Open the .ino in the same folder as both .h files.

This ZIP was checked for integrity but NOT compiled against the Arduino libraries or hardware tested.
