ADV System r0.9 — SD STREAMED SEQUENCER (EXPERIMENTAL)

Replaces RAM-resident WAV samples with four SD-backed sample voices.
Each voice retains only a 1024-byte source cache and a WAV file handle.
No full-sample PCM buffers are allocated.

WAV: 8/16-bit PCM, mono/stereo, 8–48 kHz, first 3 seconds.
Each channel restarts its sample on retrigger. 16kHz mono output.

SD ownership: all sequencer files are closed when entering USB SD mode.
Returning to sequencer after USB SD mode requires reassigning or opening
a saved pattern to reopen sample files.

Music, pattern save/load, UI, and USB MSC are otherwise inherited from r0.8.

CAUTION: SD streaming adds real-time I/O pressure. Timing and mixing
need hardware validation; four simultaneous 48kHz stereo files may glitch.
No compilation or hardware test has been performed. Keep r0.8 as fallback.

Dependencies: ESP32 3.2.1, ESP8266Audio 2.4.3 and included
AudioOutputPDM.cpp compatibility instructions.
