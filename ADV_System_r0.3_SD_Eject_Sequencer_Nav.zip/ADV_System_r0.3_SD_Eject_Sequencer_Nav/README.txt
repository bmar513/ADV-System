ADV SYSTEM r0.3 — USB SD eject and 17-position sequencer navigation

CHANGES
- Sequencer horizontal cursor has 17 positions: channel button (0), steps 1-16.
- LEFT/RIGHT traverse all 17; UP/DOWN select channels.
- ENTER on channel button opens /Samples browser; ENTER on steps starts/stops.
- SPACE toggles a selected step. 1-4 remain shortcuts for channel browser.
- Channel outline stays colored when empty and white when assigned.
- SD: BACKTICK no longer exits while Windows still owns the drive.
- Windows host eject callback marks media released; BACKTICK then reinitializes
  SD for the ADV and returns to launcher.
- Re-entering SD app re-advertises the media to the USB MSC host.

KNOWN RISKS / TESTING
- Windows may cache USB MSC media state and not detect reinserted media
  without physically reconnecting USB. This build does not force a full USB
  device re-enumeration. The re-entry behavior is experimental, not guaranteed.
- Some Windows "Safely Remove Hardware" paths disconnect the entire USB
  device instead of issuing the MSC START STOP UNIT eject command. If the
  device doesn't report eject, do not force backtick. Disconnect USB only
  after Windows confirms the device can be removed.
- This project has NOT been compiled or tested on the hardware. Back up SD.
- USB MSC callbacks and filesystem operations still need thorough testing
  for race conditions and safe media ownership; avoid irreplaceable files.
- Sequencer sound playback/mixing is NOT implemented yet.

Build environment from v1.0: ESP32 3.2.1, ESP8266Audio 2.4.3 with the
included AudioOutputPDM.cpp compatibility instructions.
