ADV SYSTEM r0.0 — EXPERIMENTAL PROTOTYPE
========================================
Built from the v1.0 working Music snapshot. Does not replace the v1.0 archive.

IMPLEMENTED
- 2x2 black launcher: MUSIC / KEYBOARD / SEQUENCER / DIAG.
- Music app: six genre shuffle queues and MP3/WAV File Player, existing decoder.
- Removed Recorder implementation and microphone initialization.
- Direct - and = volume, persisted 0–10.
- Music ENTER play/pause/resume; SPACE has no action.
- Sequencer: four colored rows of 16 gray/colored step boxes, editing,
  BPM-based moving playhead, selection, SD /samples browser, sample assignment.
- DIAG: basic battery, heap and SD status (read-only).

NOT YET IMPLEMENTED — IMPORTANT
- Sequencer AUDIO OUTPUT/MIXING. Sequencer currently edits and animates patterns
  but does not play the selected WAV/MP3 samples. This is not a functional
  audio sequencer yet. Polyphonic playback needs a separate sample mixer.
- USB HID keyboard forwarding to a connected PC. Keyboard is a placeholder
  screen, NOT yet a USB keyboard.
- DIAG electrical measurements. Do NOT attach unknown voltages or components
  for measurement based on this prototype.
- Sequencer pattern saving/loading; sample assignments do not persist.
- A clickable touchscreen is not present on Cardputer ADV; physical keys used.

CONTROLS
Launcher: ; / . up/down, , / / left/right, Enter open.
Music menu: ; . navigate, Enter open, backtick returns to launcher.
Music playback: Enter play/pause/resume, , / / previous/next, Backspace stop.
Sequencer: ; . select channel, , / / select step, Space toggle step,
Enter start/stop and reset, 1-4 open sample browser for corresponding channel,
backtick return to launcher. Volume - / =.
Sample browser: ; . navigate, Enter assign, backtick return.
DIAG / Keyboard: backtick return.

KNOWN LIMITATION
In File Player, Enter while a different item is highlighted opens that item.
Enter on the currently playing highlighted file toggles pause/resume.

BUILD
Tested v1.0 baseline used ESP32 board package 3.2.1 and ESP8266Audio 2.4.3
with the one-line AudioOutputPDM.cpp compatibility workaround (see included
reference note). This experimental revision has NOT been compiled or tested.

NEXT STEPS
1. Verify compile and basic launcher/Music navigation on hardware.
2. Implement sample mixer and proper WAV/MP3 preload for sequencer.
3. Implement USB HID keyboard (with clean connect/disconnect behavior).
4. Add DIAG guided measurement circuits, after verifying expansion pins.
