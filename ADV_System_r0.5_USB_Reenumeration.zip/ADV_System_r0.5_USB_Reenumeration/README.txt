ADV SYSTEM r0.5 — USB MSC RE-ENUMERATION EXPERIMENT
=====================================================
Based on r0.4 SD Remount Fast Entry. Music, Sequencer and DIAG retained.

CHANGES
- Adds TinyUSB tud_disconnect()/tud_connect() soft USB re-enumeration.
- On SD entry: verify local card, refresh MSC capacity, soft disconnect,
  advertise medium present, reconnect. This is intended to avoid Windows
  waiting 60–90 seconds for periodic removable-media polling.
- On Windows safe eject: callback flags the event; main loop marks medium
  absent, avoiding USB stack reconfiguration inside the callback.
- On BACKTICK: disconnect USB, advertise medium absent, reconnect USB,
  remount/verify SD locally, return to launcher.
- Next SD entry uses a new USB enumeration, including after Windows eject.
- Does not require Windows eject event to allow BACKTICK.

WARNINGS
- This changes USB enumeration. COM port may disappear/reappear on entry
  and exit; close Arduino Serial Monitor before testing.
- If Arduino upload port disappears, use ESP32-S3 BOOT + RESET ROM
  download mode to recover and flash the working r0.4 or Music v1.0.
- ALWAYS safely eject in Windows before pressing BACKTICK. Never transfer
  files while returning to launcher. Back up SD card before first test.
- USB soft disconnect/reconnect is a hypothesis-based fix. Mount time and
  post-eject remount have NOT been verified on hardware.
- Sequencer sample playback is still not implemented in this branch.

KNOWN DEVELOPMENT ENVIRONMENT
Arduino ESP32 boards 3.2.1, ESP8266Audio 2.4.3 with the included
AudioOutputPDM.cpp one-line workaround. USB mode: TinyUSB / USB-OTG.
This revision has NOT been compiled or hardware-tested.

TEST
1. Backup SD, close Serial Monitor, connect ADV.
2. Open SD; time until Windows drive letter appears.
3. Safely eject in Windows, press BACKTICK.
4. Open Music and confirm SD content available.
5. Re-enter SD without unplugging USB; time the second drive letter.
6. Repeat with normal Windows eject; check no resets required.
