ADV System r0.9b - Diagnostics dashboard

Based on r0.9a. DIAG now displays a scrollable, read-only list.
Use ; and . to scroll, backtick to exit.

Reports SD mount/export, SD capacity, battery level, heap, largest free
block, PSRAM, CPU, chip model, flash, chip ID, uptime, firmware version.

IMPORTANT: Charging reports UNKNOWN because no verified charging-state
API was established for this hardware. Microphone reports DISABLED because
the firmware explicitly disables its initialization. Speaker INITIALIZED
means the firmware called begin(), not that physical output was tested.
Chip ID is derived from the ESP eFuse MAC, not a printed product serial.

Music, SD export, sequencer, and patterns are inherited unchanged.
Not compiled or hardware-tested. Keep r0.9a as fallback.
