ADV SYSTEM r0.2 — USB SD MASS STORAGE EXPERIMENT

This revision implements ESP32-S3 USB Mass Storage Class (MSC) for the
Cardputer ADV's SPI microSD card using SD.readRAW / SD.writeRAW.
It has NOT been compiled or tested on hardware. BACK UP THE SD CARD FIRST.

Arduino settings: select a Cardputer ADV / ESP32-S3 configuration with
USB Mode = USB-OTG (TinyUSB), NOT Hardware CDC and JTAG. MSC requires
native USB OTG. The USB device stack is started at boot and exposes
media only when the SD app is selected. USB upload/serial behavior may
change with this board setting; retain a recovery upload method.

PROCEDURE
1. Back up the card using a normal PC reader before first test.
2. Flash r0.2. Connect USB-C to Windows. Enter SD app.
3. Wait for Windows to recognize the removable disk. If it doesn't,
   stop and report the result; don't format the card if prompted.
4. Copy a SMALL disposable test file first.
5. In Windows, right-click the drive -> Eject / Safely Remove.
6. After the ADV displays the ejected state, press backtick to exit.
7. Verify the file in Music browser or on a separate card reader.

IMPORTANT LIMITATIONS
- MSC capacity is configured at boot. SD must be inserted at startup.
- If Windows doesn't issue an MSC eject command, ADV won't release SD.
  Do not force exit or unplug during writes.
- No ADV-side filesystem access while Windows owns the card.
- Abrupt USB disconnection and FAT cache interactions remain UNTESTED.
- The existing Music playback and sequencer are inherited from r0.1;
  sequencer audio mixing is still NOT implemented.
- Do not trust this experimental build with irreplaceable files.

Working Music v1.0 remains the recovery baseline. Dependencies:
ESP32 3.2.1 + ESP8266Audio 2.4.3 with the documented PDM workaround.
