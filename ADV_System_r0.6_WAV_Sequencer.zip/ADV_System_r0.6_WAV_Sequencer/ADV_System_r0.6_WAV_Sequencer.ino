#include <M5Cardputer.h>
#include <SPI.h>
#include <SD.h>
#include <USB.h>
#include <USBMSC.h>
#include <tusb.h> // TinyUSB soft disconnect/reconnect for fresh host enumeration
#include <Preferences.h>
#include <AudioFileSourceSD.h>
#include <AudioGeneratorMP3.h>
#include <AudioGeneratorWAV.h>
#include <AudioOutput.h>
#include <atomic>
#include <esp_heap_caps.h>
#include <vector>
#include <freertos/semphr.h>
#include "AudioOutputM5Speaker.h"

// ADV System r0.6 — experimental launcher and application scaffolding built on Music v1.0.
// HOME / browser: ; up, . down, Enter select, ` back.
// Music: Enter play/pause, , previous, / next, Backspace stop.
// Genre folders at SD root: Industrial, Rap, Desert, Metal, Rock, Electro.
// File Player: MP3 and PCM WAV. Recorder has been removed.
static const int SD_CS=12, SD_SCK=40, SD_MISO=39, SD_MOSI=14;
static const int MAX_TRACKS=2500; // Upper bound; actual capacity depends on free heap
static const char* GENRE_NAMES[]={"INDUSTRIAL","RAP","DESERT","METAL","ROCK","ELECTRO"};
static const char* GENRE_DIRS[]={"/Industrial","/Rap","/Desert","/Metal","/Rock","/Electro"};
static const int GENRE_COUNT=sizeof(GENRE_NAMES)/sizeof(GENRE_NAMES[0]);
static const int MENU_COUNT=GENRE_COUNT+1;
static_assert(sizeof(GENRE_NAMES)/sizeof(GENRE_NAMES[0])==sizeof(GENRE_DIRS)/sizeof(GENRE_DIRS[0]), "Genre names and directories must match");
enum Mode { LAUNCHER, HOME, GENRE_PLAYER, FILE_BROWSER, FOLDER_PLAYER, SEQUENCER, SAMPLE_BROWSER, SD_APP, DIAG_APP };
Mode mode=LAUNCHER;
USBMSC msc;
volatile bool hostEjected=false;
volatile uint32_t mscLastIO=0;
bool sdExported=false,sdExportError=false;
volatile bool usbMediaEjectPending=false;
bool usbMSCStarted=false;

static const int MAX_ENTRIES=150;
String browserNames[MAX_ENTRIES],browserPaths[MAX_ENTRIES];
bool browserFolders[MAX_ENTRIES];
int browserCount=0,browserSelection=0;
String browserPath="/", folderPlayingPath="";
bool folderFinished=false;
std::vector<String> tracks;
SemaphoreHandle_t sdMutex=nullptr;
bool folderQueueActive=false;
int trackCount=0, selection=0, volume=4; // User-facing 0..10 steps
// Map ten equal user-facing steps onto the M5 speaker's 0..255 scale.
uint8_t speakerVolume(){return (uint8_t)((volume*255+5)/10);}
// Mic input selection is a diagnostic: ADV codec data may be mapped to either I2S slot.


bool sdOK=false;
int launcherChoice=0;
bool steps[4][16]={};
String samplePaths[4];
String sampleNames[80];
int sampleCount=0,sampleChoice=0,seqChannel=0,seqStep=0,seqBpm=120;
int seqCursor=1; // 0 = channel button, 1..16 = step boxes
bool seqRunning=false;
uint32_t seqLastTick=0;
bool waitForDecoderStop();

// Sequencer r0.6: 16-bit mono PCM WAV samples at 16000 Hz, RAM-resident.
// Four independently restarting voices, mixed with saturation into one stream.
// Other sample rates/formats are rejected rather than played at wrong pitch.
static const uint32_t SEQ_RATE=16000;
static const size_t SEQ_MAX_FRAMES=SEQ_RATE*3; // 3 seconds/channel maximum
struct SeqVoice { int16_t* pcm=nullptr; size_t frames=0; size_t pos=0; };
SeqVoice seqVoices[4];
SemaphoreHandle_t seqMutex=nullptr;
volatile bool seqAudioEnabled=false;
volatile bool seqResetRequested=false;
volatile uint32_t seqTriggerMask=0;
String sampleError="";
uint16_t wavU16(File &f){uint8_t b[2];if(f.read(b,2)!=2)return 0;return uint16_t(b[0])|(uint16_t(b[1])<<8);}
uint32_t wavU32(File &f){uint8_t b[4];if(f.read(b,4)!=4)return 0;return uint32_t(b[0])|(uint32_t(b[1])<<8)|(uint32_t(b[2])<<16)|(uint32_t(b[3])<<24);}
bool loadSeqSample(int channel,const String &path){
 if(channel<0||channel>=4||sdExported||!sdOK)return false;
 if(!waitForDecoderStop())return false;
 if(!sdMutex||xSemaphoreTake(sdMutex,pdMS_TO_TICKS(1000))!=pdTRUE)return false;
 File f=SD.open(path,FILE_READ);
 bool valid=false;uint32_t dataAt=0,dataBytes=0,rate=0;uint16_t fmt=0,chans=0,bits=0;
 if(f && f.size()>=44){
  char magic[4];f.readBytes(magic,4);uint32_t riffSize=wavU32(f);
  char wave[4];f.readBytes(wave,4);
  if(memcmp(magic,"RIFF",4)==0&&memcmp(wave,"WAVE",4)==0){
   while(f.position()+8<=f.size()){
    char id[4];f.readBytes(id,4);uint32_t len=wavU32(f);
    uint32_t at=f.position();if(len>f.size()-at)break;
    if(memcmp(id,"fmt ",4)==0&&len>=16){
     fmt=wavU16(f);chans=wavU16(f);rate=wavU32(f);wavU32(f);wavU16(f);bits=wavU16(f);
    }else if(memcmp(id,"data",4)==0){dataAt=at;dataBytes=len;}
    uint32_t next=at+len+(len&1);if(next>f.size())break;
    f.seek(next);
   }
   valid=(fmt==1&&chans==1&&bits==16&&rate==SEQ_RATE&&dataBytes>=2&&dataAt>0);
  }
 }
 if(!valid){if(f)f.close();xSemaphoreGive(sdMutex);sampleError="USE 16K MONO PCM WAV";return false;}
 size_t frames=std::min((size_t)(dataBytes/2),SEQ_MAX_FRAMES);
 int16_t* pcm=(int16_t*)heap_caps_malloc(frames*sizeof(int16_t),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
 if(!pcm)pcm=(int16_t*)malloc(frames*sizeof(int16_t));
 if(!pcm){f.close();xSemaphoreGive(sdMutex);sampleError="NOT ENOUGH MEMORY";return false;}
 f.seek(dataAt);size_t got=f.read((uint8_t*)pcm,frames*sizeof(int16_t));
 f.close();xSemaphoreGive(sdMutex);
 if(got!=frames*sizeof(int16_t)){free(pcm);sampleError="WAV READ FAILED";return false;}
 if(xSemaphoreTake(seqMutex,pdMS_TO_TICKS(1000))!=pdTRUE){free(pcm);return false;}
 int16_t* old=seqVoices[channel].pcm;
 seqVoices[channel].pcm=pcm;seqVoices[channel].frames=frames;seqVoices[channel].pos=frames;
 samplePaths[channel]=path;
 xSemaphoreGive(seqMutex);
 if(old)free(old);
 sampleError="";return true;
}
void seqAudioTask(void*){
 static int16_t mix[256];
 for(;;){
  if(!seqAudioEnabled){vTaskDelay(pdMS_TO_TICKS(10));continue;}
  if(xSemaphoreTake(seqMutex,pdMS_TO_TICKS(10))!=pdTRUE){vTaskDelay(1);continue;}
  uint32_t triggers=seqTriggerMask;seqTriggerMask=0;
  if(seqResetRequested){for(auto &v:seqVoices)v.pos=v.frames;seqResetRequested=false;}
  for(int c=0;c<4;c++)if(triggers&(1u<<c))seqVoices[c].pos=0;
  for(size_t i=0;i<256;i++){
   int32_t sum=0;
   for(auto &v:seqVoices)if(v.pcm&&v.pos<v.frames)sum+=v.pcm[v.pos++];
   if(sum>32767)sum=32767;else if(sum<-32768)sum=-32768;
   mix[i]=(int16_t)sum;
  }
  xSemaphoreGive(seqMutex);
  // Queue 16 ms of mixed PCM to M5 speaker. This is NOT four MP3 decoders.
  M5Cardputer.Speaker.playRaw(mix,256,SEQ_RATE,false,0,false);
  vTaskDelay(pdMS_TO_TICKS(14));
 }
}
void stopSeq(){seqRunning=false;seqAudioEnabled=false;seqResetRequested=true;seqTriggerMask=0;seqStep=0;M5Cardputer.Speaker.stop();}
void fireSeqStep(int step){
 uint32_t mask=0;
 for(int c=0;c<4;c++)if(steps[c][step]&&seqVoices[c].pcm)mask|=1u<<c;
 seqTriggerMask|=mask;
}

// SD card USB Mass Storage callbacks. All access must be exclusive.
// SD library uses SPI and provides sector-level readRAW/writeRAW.
static int32_t mscRead(uint32_t lba,uint32_t offset,void *buffer,uint32_t size){
 mscLastIO=millis();
 if(!sdExported||!sdOK||offset!=0||size%SD.sectorSize())return -1;
 const uint32_t sec=SD.sectorSize();
 if(lba+size/sec>SD.numSectors())return -1;
 uint8_t *p=(uint8_t*)buffer;
 for(uint32_t i=0;i<size/sec;i++)if(!SD.readRAW(p+i*sec,lba+i))return -1;
 return size;
}
static int32_t mscWrite(uint32_t lba,uint32_t offset,uint8_t *buffer,uint32_t size){
 mscLastIO=millis();
 if(!sdExported||!sdOK||offset!=0||size%SD.sectorSize())return -1;
 const uint32_t sec=SD.sectorSize();
 if(lba+size/sec>SD.numSectors())return -1;
 for(uint32_t i=0;i<size/sec;i++)if(!SD.writeRAW(buffer+i*sec,lba+i))return -1;
 return size;
}
static bool mscStartStop(uint8_t power,bool start,bool loadEject){
 if(loadEject&&!start){hostEjected=true;usbMediaEjectPending=true;}
 return true;
}
// Check the filesystem is usable locally, not merely that SD.begin returned true.
bool localSDReady(){
 if(!sdOK)return false;
 File root=SD.open("/");
 bool ok=(bool)root && root.isDirectory();
 if(root)root.close();
 return ok;
}
// Reinitialize the SD card with bounded retries after relinquishing USB MSC.
// Never let another app access the card unless its filesystem is verified.
bool remountLocalSD(){
 if(sdMutex&&xSemaphoreTake(sdMutex,pdMS_TO_TICKS(1500))!=pdTRUE)return false;
 bool ok=false;
 for(int attempt=0;attempt<4;attempt++){
  SD.end();
  delay(80+attempt*100);
  sdOK=SD.begin(SD_CS,SPI,25000000);
  ok=localSDReady();
  Serial.printf("SD: local remount attempt=%d begin=%d root=%d\n",attempt+1,sdOK,ok);
  if(ok)break;
 }
 sdOK=ok;
 if(sdMutex)xSemaphoreGive(sdMutex);
 return ok;
}
// Force Windows to re-enumerate the already-initialized USB device.
// The Arduino ESPUSB class has no USB.end(); TinyUSB supplies soft detach.
// Only call from main loop, NEVER from USB callbacks.
void usbReenumerate(bool mediumPresent){
  tud_disconnect();
  delay(300); // Host must see a real disconnect before reconnect.
  msc.mediaPresent(mediumPresent);
  delay(20);
  tud_connect();
  Serial.printf("MSC: USB re-enumerated; medium=%d at %lu ms\n",mediumPresent,(unsigned long)millis());
}
void beginSDExport(){
 sdExportError=false;hostEjected=false;usbMediaEjectPending=false;mscLastIO=millis();
 if(!waitForDecoderStop()){sdExportError=true;return;}
 if(sdMutex&&xSemaphoreTake(sdMutex,pdMS_TO_TICKS(1000))!=pdTRUE){sdExportError=true;return;}
 bool ready=localSDReady();
 if(!ready){
  SD.end();
  sdOK=SD.begin(SD_CS,SPI,25000000);
  ready=localSDReady();
 }
 if(ready&&SD.sectorSize()==512&&SD.numSectors()>0){
  // Reinitialize MSC geometry in case card was changed while locally mounted.
  msc.mediaPresent(false);
  if(msc.begin(SD.numSectors(),SD.sectorSize())){
   usbMSCStarted=true;
   sdExported=true;
   // The USB cable stays connected; this soft detach makes Windows
   // enumerate a new medium instead of waiting for periodic TEST UNIT READY.
   usbReenumerate(true);
  }else{sdExportError=true;sdExported=false;}
 }else{sdExportError=true;sdExported=false;}
 if(sdMutex)xSemaphoreGive(sdMutex);
}
bool endSDExport(){
 // User must EJECT IN WINDOWS before pressing BACKTICK.
 // Withdraw medium even if the host did not send the eject callback.
 sdExported=false;
 usbMediaEjectPending=false;
 usbReenumerate(false);
 // USB is now connected without an SD medium. Windows sees its removal.
 delay(100);
 bool ok=remountLocalSD();
 sdExportError=!ok;
 hostEjected=false;
 Serial.printf("SD: returned to ADV; filesystem=%s\n",ok?"READY":"FAILED");
 return ok;
}
void scanSamples(){
 sampleCount=0;sampleChoice=0;
 if(!sdOK)return;
 if(sdMutex && xSemaphoreTake(sdMutex,pdMS_TO_TICKS(300))!=pdTRUE)return;
 File dir=SD.open("/Samples");
 if(dir && dir.isDirectory()){
  File f=dir.openNextFile();
  while(f&&sampleCount<80){
   String n=String(f.name());
   if(!f.isDirectory()){
    String lower=n;lower.toLowerCase();
    if(lower.endsWith(".wav"))
     sampleNames[sampleCount++]=n.startsWith("/")?n.substring(n.lastIndexOf('/')+1):n;
   }
   f.close();f=dir.openNextFile();
  }
  dir.close();
 }
 if(sdMutex)xSemaphoreGive(sdMutex);
}
int menuSelection=0, lastCycleTrack=-1;
bool inMenu=true;
uint32_t lastPaint=0, lastKey=0, lastBatteryPaint=0;
uint32_t volumeChangedAt=0;
bool volumeDirty=false;
Preferences prefs;

// Decoder and SD file ownership belong only to decodeTask.
AudioFileSourceSD *mp3File=nullptr;
AudioGenerator *decoder=nullptr;
AudioOutputM5Speaker mp3Output(&M5Cardputer.Speaker,0);
std::atomic<bool> playing{false}, paused{false}, engineIdle{true};
std::atomic<int> active{-1};
std::atomic<int> requestedTrack{-1}; // -1 no request, -2 stop, >=0 queue index
std::atomic<int> finishedTrack{-1};

String basename(const String &s){int p=s.lastIndexOf('/');return p>=0?s.substring(p+1):s;}
// Trim by measured pixel width, not a guessed character count. No auto-wrap into
// the battery column or outside the physical display.
String fitPixels(const String &s,int maxPixels,bool ellipsis=false){
 auto &d=M5Cardputer.Display;
 if(maxPixels<=0)return "";
 if((int)d.textWidth(s)<=maxPixels)return s;
 String out=s;
 String tail=ellipsis?"...":"";
 while(out.length() && (int)d.textWidth(out+tail)>maxPixels)out.remove(out.length()-1);
 return out+tail;
}
// Page long titles instead of moving one character at a time.
// A page stays visible for 2.4 seconds; no animated redraws.
String titlePage(const String &s,int maxPixels,uint32_t page){
 auto &d=M5Cardputer.Display;
 if((int)d.textWidth(s)<=maxPixels)return s;
 std::vector<String> pages;
 int pos=0;
 while(pos<(int)s.length()){
  int end=pos;
  while(end<(int)s.length() && (int)d.textWidth(s.substring(pos,end+1))<=maxPixels)end++;
  if(end==pos)end++;
  pages.push_back(s.substring(pos,end));
  pos=end;
 }
 return pages.empty()?"":pages[page%pages.size()];
}
int menuFirst=0;
void keepMenuVisible(){
 int rows=max(1, (int)((M5Cardputer.Display.height()-29)/19));
 if(menuSelection<menuFirst)menuFirst=menuSelection;
 if(menuSelection>=menuFirst+rows)menuFirst=menuSelection-rows+1;
}
void batteryAtTop(){
 int battery=M5.Power.getBatteryLevel();
 if(battery>=0&&battery<=100){
  auto &d=M5Cardputer.Display;
  d.setTextColor(WHITE,BLACK);d.setCursor(d.width()-51,3);d.printf("%d%%",battery);
 }
}
void draw(bool full=true){
 auto &d=M5Cardputer.Display;
 int w=d.width(),h=d.height();
 uint32_t phase=millis()/2400;
 if(full)d.fillScreen(BLACK);
 d.setTextSize(1);d.setTextFont(2);
 d.setTextWrap(false);
 // Battery occupies only the top-right header. All body rows get full width.
 d.fillRect(0,0,w,25,BLACK);
 d.setCursor(4,3);d.setTextColor(WHITE,BLACK);
 String header;
 if(mode==HOME)header="MUSIC";
 else if(mode==FILE_BROWSER)header="FILE PLAYER";
 else if(mode==LAUNCHER)header="ADV SYSTEM r0.6";
 else if(mode==SEQUENCER)header=String(seqBpm)+" BPM";
 else if(mode==SAMPLE_BROWSER)header="SAMPLES";
 else if(mode==SD_APP)header="SD";
 else if(mode==DIAG_APP)header="DIAG";
 else if(mode==GENRE_PLAYER && menuSelection>=0 && menuSelection<GENRE_COUNT)header=GENRE_NAMES[menuSelection];
 else header="PLAYER";
 d.print(fitPixels(header,w-59,true));
 batteryAtTop();
 if(!full)return;
 d.drawFastHLine(0,25,w,0x7BEF);
 if(mode==LAUNCHER){
  const char* labels[]={"MUSIC","SD","SEQUENCER","DIAG"};
  int gap=6, top=30, boxW=(w-3*gap)/2, boxH=(h-top-3*gap)/2;
  for(int i=0;i<4;i++){
   int x=gap+(i%2)*(boxW+gap),y=top+gap+(i/2)*(boxH+gap);
   d.fillRoundRect(x,y,boxW,boxH,5,i==launcherChoice?0x2945:0x2104);
   d.drawRoundRect(x,y,boxW,boxH,5,i==launcherChoice?0x07E0:0x8410);
   d.setTextColor(WHITE,i==launcherChoice?0x2945:0x2104);
   d.setCursor(x+(boxW-d.textWidth(labels[i]))/2,y+(boxH-d.fontHeight())/2);d.print(labels[i]);
  }
  return;
 }
 if(mode==SEQUENCER){
  const uint16_t colors[]={0x05FF,0xFD20,0xA51F,0x07E0};
  int x0=26, gap=2, sw=(w-x0-4-15*gap)/16;
  for(int c=0;c<4;c++){
   int y=30+c*24;
   // Channel-number button: white outline indicates loaded sample.
   d.fillRoundRect(2,y-1,21,19,3,BLACK);
   d.drawRoundRect(2,y-1,21,19,3,samplePaths[c].length()?WHITE:colors[c]);
   if(c==seqChannel&&seqCursor==0)d.drawRoundRect(1,y-2,23,21,3,WHITE);
   d.setTextColor(colors[c],BLACK);d.setCursor(8,y+2);
   d.printf("%d",c+1);
   for(int t=0;t<16;t++){
    int x=x0+t*(sw+gap);
    d.fillRect(x,y,sw,17,steps[c][t]?colors[c]:0x8410);
    if(c==seqChannel&&seqCursor==t+1)d.drawRect(x-1,y-1,sw+2,19,WHITE);
   }
  }
  return;
 }
 if(mode==SAMPLE_BROWSER){
  d.setTextColor(WHITE,BLACK);d.setCursor(4,28);d.print("/Samples/");
  for(int i=0;i<sampleCount&&i<5;i++){
   d.setTextColor(i==sampleChoice?GREEN:WHITE,BLACK);
   d.setCursor(4,47+i*17);d.print(fitPixels(String(i==sampleChoice?"> ":"  ")+sampleNames[i],w-8,true));
  }
  if(!sampleCount){d.setCursor(4,50);d.print("NO WAV IN /Samples");}
  if(sampleError.length()){d.setTextColor(RED,BLACK);d.setCursor(4,h-16);d.print(fitPixels(sampleError,w-8));}
  return;
 }
 if(mode==SD_APP){
  d.setTextColor(WHITE,BLACK);d.setCursor(4,35);d.print("USB SD DRIVE");
  d.setCursor(4,56);d.print(sdExportError?"SD ERROR - ` RETRY":(sdExported?"USB DRIVE ACTIVE":"SD NOT EXPORTED"));
  d.setCursor(4,79);d.print("1. Eject in Windows");
  d.setCursor(4,102);d.print("2. ` to exit SD");return;
 }
 if(mode==DIAG_APP){
  d.setTextColor(WHITE,BLACK);d.setCursor(4,30);
  d.print("DIAG - INFORMATION");
  d.setCursor(4,51);d.printf("Battery: %d%%",M5.Power.getBatteryLevel());
  d.setCursor(4,72);d.printf("Free heap: %u",ESP.getFreeHeap());
  d.setCursor(4,93);d.printf("SD: %s",sdOK?"READY":"MISSING");
  d.setCursor(4,114);d.print("No voltage applied to GPIO");return;
 }
 if(mode==HOME){
  int rows=max(1,(int)((h-29)/19));
  keepMenuVisible();
  int start=menuFirst;
  for(int i=start;i<MENU_COUNT&&i<start+rows;i++){
   int y=29+(i-start)*19;
   d.setTextColor(i==menuSelection?GREEN:WHITE,BLACK);d.setCursor(5,y);
   d.print(i==menuSelection?"> ":"  ");
   d.print(i<GENRE_COUNT?GENRE_NAMES[i]:"FILE PLAYER");
  }
  if(!sdOK){d.setTextColor(RED,BLACK);d.setCursor(4,h-18);d.print("SD CARD ERROR");}return;
 }
 if(mode==FILE_BROWSER){
  d.setTextColor(WHITE,BLACK);d.setCursor(4,28);d.print(fitPixels(browserPath,w-8,true));
  // Playing title gets its own full-width line. The list never animates.
  if(folderQueueActive&&active.load()>=0&&active.load()<trackCount){
   d.setTextColor(playing.load()?(paused.load()?0xFD20:GREEN):WHITE,BLACK);
   d.setCursor(4,46);
   d.print(titlePage(basename(tracks[active.load()]),w-8,phase));
  }
  int rows=max(1,(h-73)/18), start=max(0,browserSelection-rows/2);
  if(start+rows>browserCount)start=max(0,browserCount-rows);
  for(int i=start;i<browserCount&&i<start+rows;i++){
   bool isCurrent=folderQueueActive && active.load()>=0 && active.load()<trackCount && browserPaths[i]==tracks[active.load()];
   d.setTextColor(isCurrent&&playing.load()&&paused.load()?0xFD20:(i==browserSelection?GREEN:WHITE),BLACK);
   d.setCursor(4,69+(i-start)*18);
   String line=String(i==browserSelection?">":" ")+(browserFolders[i]?"[D] ":"    ")+browserNames[i];
   d.print(fitPixels(line,w-8,true));
  }
  if(!browserCount){d.setCursor(4,69);d.print("EMPTY FOLDER");}
  return;
 }
 if(mode==GENRE_PLAYER){
  if(!trackCount){d.setTextColor(WHITE,BLACK);d.setCursor(4,33);d.print("NO MP3 FILES");return;}
  int a=active.load();if(a<0||a>=trackCount)a=selection;
  if(a<0||a>=trackCount)return;
  // Song title directly under the header; no second copy of the genre name.
  d.setTextColor(playing.load()?(paused.load()?0xFD20:GREEN):WHITE,BLACK);
  d.setCursor(4,30);
  d.print(titlePage(basename(tracks[a]),w-8,phase));
  int indices[]={a-1,a,a+1};
  for(int row=0;row<3;row++){
   int idx=indices[row];if(idx<0||idx>=trackCount)continue;
   bool current=(row==1);
   d.setTextColor(current?(playing.load()?(paused.load()?0xFD20:GREEN):WHITE):WHITE,BLACK);
   d.setCursor(4,54+row*22);
   String line=String(current?"> ":"  ")+basename(tracks[idx]);
   d.print(fitPixels(line,w-8,true));
  }
  return;
 }
}
void stopDecoder(){
 if(decoder){decoder->stop();delete decoder;decoder=nullptr;}
 if(mp3File){mp3File->close();delete mp3File;mp3File=nullptr;}
 M5Cardputer.Speaker.stop();
 playing=false;paused=false;active=-1;
}
bool openMp3(int index){
 stopDecoder();
 if(index<0||index>=trackCount)return false;
 Serial.printf("AUDIO: opening %s\n",tracks[index].c_str());
 mp3File=new AudioFileSourceSD(tracks[index].c_str());
 if(!mp3File||!mp3File->isOpen()){Serial.println("MP3: open failed");stopDecoder();return false;}
 String path=tracks[index];path.toLowerCase();
 decoder=path.endsWith(".wav") ? (AudioGenerator*)new AudioGeneratorWAV() : (AudioGenerator*)new AudioGeneratorMP3();
 if(!decoder||!decoder->begin(mp3File,&mp3Output)){
  Serial.println("MP3: decoder begin failed");stopDecoder();return false;
 }
 active=index;playing=true;paused=false;
 Serial.println("MP3: started");
 return true;
}
void decodeTask(void*){
 for(;;){
  int req=requestedTrack.exchange(-1);
  if(req!=-1){
   engineIdle=false;
   if(sdMutex)xSemaphoreTake(sdMutex,portMAX_DELAY);
   if(req==-2)stopDecoder();
   else if(!openMp3(req))finishedTrack=req; // Skip unplayable files.
   engineIdle=true;
   if(sdMutex)xSemaphoreGive(sdMutex);
  }
  if(playing.load()&&!paused.load()&&decoder){
   engineIdle=false;
   if(sdMutex)xSemaphoreTake(sdMutex,portMAX_DELAY);
   if(!decoder->isRunning()||!decoder->loop()){
    int completed=active.load();
    Serial.printf("MP3: finished queue index %d\n",completed);
    stopDecoder();
    if(completed>=0)finishedTrack=completed;
   }
   engineIdle=true;
   if(sdMutex)xSemaphoreGive(sdMutex);
  }else vTaskDelay(pdMS_TO_TICKS(5));
  // Give folder navigation a chance to acquire the SD mutex between audio frames.
  // taskYIELD alone may immediately reschedule this higher-priority decoder task.
  vTaskDelay(pdMS_TO_TICKS(1));
 }
}
void stopTrack(){
 finishedTrack=-1;
 requestedTrack=-2;
 playing=false;paused=false;active=-1;
}
// All scanning/shuffling occurs on the UI task, never during decoder SD reads.
// Wait for decoder to acknowledge stop before touching the directory structure.
bool waitForDecoderStop(){
 stopTrack();
 uint32_t start=millis();
 while(millis()-start<3000){
  if(requestedTrack.load()==-1&&engineIdle.load()&&!playing.load())return true;
  delay(5);
 }
 Serial.println("MP3: stop timeout; scan canceled");
 return false;
}
void scanDir(const String &path,int depth){
 if(depth>8||trackCount>=MAX_TRACKS)return;
 File dir=SD.open(path);
 if(!dir||!dir.isDirectory())return;
 File f=dir.openNextFile();
 while(f&&trackCount<MAX_TRACKS){
  String n=String(f.name());
  String full=n.startsWith("/")?n:path+"/"+n;
  bool isdir=f.isDirectory();f.close();
  if(isdir)scanDir(full,depth+1);
  else{
   String lower=full;lower.toLowerCase();
   if(lower.endsWith(".mp3")){
   // Avoid memory exhaustion on very large collections.
   if(ESP.getFreeHeap()<45000){Serial.println("JUKEBOX: low heap, ending scan");break;}
   tracks.push_back(full);trackCount=(int)tracks.size();
  }
  }
  f=dir.openNextFile();
 }
 dir.close();
}
void shuffleTracks(int avoidLast){
 // Fisher-Yates shuffle: each track occurs exactly once per cycle.
 for(int i=trackCount-1;i>0;i--){
  int j=(int)random(i+1);
  String temp=tracks[i];tracks[i]=tracks[j];tracks[j]=temp;
 }
 if(trackCount>1&&avoidLast>=0&&avoidLast<trackCount){
  // avoidLast is the old last track's position only before a shuffle.
  // The previous song is saved as a path by the caller instead.
 }
}
void requestPlay(int index){
 if(index<0||index>=trackCount)return;
 finishedTrack=-1;
 requestedTrack=index;
 active=index;playing=true;paused=false;
 draw();
}
void startCategory(int category){
 if(!sdOK)return;
 if(!waitForDecoderStop())return;
 tracks.clear();trackCount=0;selection=0;lastCycleTrack=-1;
 String dir=GENRE_DIRS[category];
 scanDir(dir,0);
 Serial.printf("JUKEBOX: scanned %s, %d MP3 files; free heap=%u\n",dir.c_str(),trackCount,(unsigned)ESP.getFreeHeap());
 if(trackCount>0)shuffleTracks(-1);
 menuSelection=category;mode=GENRE_PLAYER;inMenu=false;
 draw();
 if(trackCount>0)requestPlay(0);
}
void returnToMenu(){
 if(!waitForDecoderStop())return;
 folderQueueActive=false;inMenu=true;mode=HOME;
 tracks.clear();trackCount=0;selection=0;lastCycleTrack=-1;
 // Do not scan SD here; the decoder may still be finishing a frame.
 draw();
}
void advance(int delta){
 if(mode==HOME||trackCount==0)return;
 int base=active.load();
 if(base<0||base>=trackCount)base=selection;
 selection=(base+delta+trackCount)%trackCount;
 requestPlay(selection);
}
void autoAdvance(int completed){
 if((mode!=GENRE_PLAYER&&!folderQueueActive)||trackCount==0||completed<0||completed>=trackCount)return;
 // A queued manual play or stop always wins over an end-of-track notification.
 if(requestedTrack.load()!=-1)return;
 int next=completed+1;
 if(next>=trackCount){
  if(folderQueueActive){folderFinished=true;selection=completed;draw();return;}
  String previous=tracks[completed];
  shuffleTracks(-1);
  if(trackCount>1&&tracks[0]==previous){
   int j=1+(int)random(trackCount-1);
   String temp=tracks[0];tracks[0]=tracks[j];tracks[j]=temp;
  }
  next=0;
  Serial.println("JUKEBOX: new shuffled cycle");
 }
 selection=next;
 requestPlay(next);
}
bool audioPath(String p){p.toLowerCase();return p.endsWith(".mp3")||p.endsWith(".wav");}
bool browserScanPending=false;
void scanBrowser(){
 // Never freeze the UI waiting indefinitely for SD while a track is decoding.
 if(sdMutex && xSemaphoreTake(sdMutex,pdMS_TO_TICKS(1000))!=pdTRUE){
  Serial.println("FILES: SD busy, folder scan deferred");
  browserScanPending=true;
  return;
 }
 browserScanPending=false;
 browserCount=0;browserSelection=0;
 File dir=SD.open(browserPath);
 if(!dir||!dir.isDirectory()){if(dir)dir.close();if(sdMutex)xSemaphoreGive(sdMutex);return;}
 File f=dir.openNextFile();
 while(f&&browserCount<MAX_ENTRIES){
  String name=String(f.name());
  String full=name.startsWith("/")?name:(browserPath=="/"?"/"+name:browserPath+"/"+name);
  bool folder=f.isDirectory();f.close();
  if(folder||audioPath(full)){
   browserNames[browserCount]=basename(full);browserPaths[browserCount]=full;
   browserFolders[browserCount++]=folder;
  }
  f=dir.openNextFile();
 }
 dir.close();
 if(sdMutex)xSemaphoreGive(sdMutex);
}
void openBrowser(){
 if(!sdOK||!waitForDecoderStop())return;
 mode=FILE_BROWSER;folderQueueActive=false;inMenu=false;browserPath="/";scanBrowser();draw();
}
void browserBack(){
 if(browserPath=="/"){folderQueueActive=false;returnToMenu();return;}
 int slash=browserPath.lastIndexOf('/');
 browserPath=slash<=0?"/":browserPath.substring(0,slash);
 scanBrowser();draw();
}
void chooseBrowserEntry(){
 if(browserCount==0)return;
 String target=browserPaths[browserSelection];
 if(browserFolders[browserSelection]){browserPath=target;scanBrowser();draw();return;}
 if(folderQueueActive && playing.load() && paused.load() && active.load()>=0 && active.load()<trackCount && tracks[active.load()]==target){paused=false;draw();return;}
 if(folderQueueActive && !playing.load() && selection>=0 && selection<trackCount && tracks[selection]==target){requestPlay(selection);return;}
 if(!waitForDecoderStop())return;
 folderPlayingPath=browserPath;
 tracks.clear();trackCount=0;selection=0;folderFinished=false;
 // Scan only this directory, not nested subdirectories, in directory order.
 File dir=SD.open(folderPlayingPath);
 if(dir&&dir.isDirectory()){
  File f=dir.openNextFile();
  while(f&&trackCount<MAX_TRACKS){
   String name=String(f.name());
   String full=name.startsWith("/")?name:(folderPlayingPath=="/"?"/"+name:folderPlayingPath+"/"+name);
   bool folder=f.isDirectory();f.close();
   if(!folder&&audioPath(full)){
    if(ESP.getFreeHeap()<45000){Serial.println("FILES: low heap, ending scan");break;}
    tracks.push_back(full);trackCount=(int)tracks.size();
   }
   f=dir.openNextFile();
  }
 }
 if(dir)dir.close();
 for(int i=0;i<trackCount;i++)if(tracks[i]==target){selection=i;break;}
 folderQueueActive=true;mode=FILE_BROWSER;scanBrowser();draw();requestPlay(selection);
}
void setup(){
 Serial.begin(115200);
 auto cfg=M5.config();
 cfg.internal_mic=false; // Explicitly request ADV ES8311 ADC microphone initialization.
 cfg.internal_spk=true;
 M5Cardputer.begin(cfg,true);
 
 M5Cardputer.Display.setRotation(0);
 prefs.begin("adv-jukebox",false);
 // Migrate existing 0..255 setting only once; thereafter persist 0..10.
 int oldVolume=constrain(prefs.getInt("volume",90),0,255);
 volume=constrain(prefs.getInt("vol10",(oldVolume*10+127)/255),0,10);
 M5Cardputer.Speaker.begin();M5Cardputer.Speaker.setVolume(speakerVolume());
 mp3Output.setup();
 SPI.begin(SD_SCK,SD_MISO,SD_MOSI,SD_CS);
 sdOK=SD.begin(SD_CS,SPI,25000000);
 sdMutex=xSemaphoreCreateMutex();
 seqMutex=xSemaphoreCreateMutex();
 // Initialize USB MSC before starting USB; medium is absent until SD app.
 msc.vendorID("M5STACK");msc.productID("ADV SD CARD");msc.productRevision("0.5");
 msc.onRead(mscRead);msc.onWrite(mscWrite);msc.onStartStop(mscStartStop);
 msc.mediaPresent(false);
 if(sdOK&&SD.sectorSize()==512&&SD.numSectors()>0){
  usbMSCStarted=msc.begin(SD.numSectors(),512);
 }else{
  // No card at boot: capacity unavailable; report via SD screen.
  sdExportError=true;
 }
 USB.begin();
 randomSeed((uint32_t)esp_random());
 Serial.printf("ADV SYSTEM r0.6 SD=%d volume=%d/10\n",sdOK,volume);
 draw();
 BaseType_t taskResult=xTaskCreatePinnedToCore(decodeTask,"mp3decode",8192,nullptr,2,nullptr,1);
 Serial.printf("MP3 decode task created=%d\n",taskResult==pdPASS);
 xTaskCreatePinnedToCore(seqAudioTask,"seqmix",4096,nullptr,1,nullptr,0);
}
void loop(){
 M5Cardputer.update();
 // Windows sent SCSI START STOP UNIT with LoEj=1, Start=0.
 // Do not re-enumerate here: Windows is completing the eject transaction.
 // Mark the medium absent. BACKTICK will do a full fresh USB enumeration.
 if(usbMediaEjectPending){
  usbMediaEjectPending=false;
  msc.mediaPresent(false);
  Serial.println("MSC: Windows eject received; medium marked absent");
 }

 static uint32_t lastBrowserRetry=0;
 if(mode==FILE_BROWSER && browserScanPending && millis()-lastBrowserRetry>=200){
  lastBrowserRetry=millis();scanBrowser();
  if(!browserScanPending)draw();
 }
 // Persist volume once after changes settle, to reduce NVS writes.
 if(volumeDirty&&millis()-volumeChangedAt>1800){
  prefs.putInt("vol10",volume);volumeDirty=false;
  Serial.printf("JUKEBOX: saved volume %d\n",volume);
 }
 int completed=finishedTrack.exchange(-1);
 if(completed>=0&&(mode==GENRE_PLAYER||folderQueueActive))autoAdvance(completed);
 static bool oldPlaying=false,oldPaused=false;
 static int oldActive=-1;
 static bool oldMenu=true;
 if(oldPlaying!=playing.load()||oldPaused!=paused.load()||oldActive!=active.load()||oldMenu!=inMenu){
  oldPlaying=playing;oldPaused=paused;oldActive=active;oldMenu=inMenu;
  draw();
 }
 if(millis()-lastPaint>=2400){
  lastPaint=millis();
  auto &d=M5Cardputer.Display;
  d.setTextSize(1);d.setTextFont(2);
  if(mode==GENRE_PLAYER&&trackCount>0){
   int a=active.load();if(a<0||a>=trackCount)a=selection;
   if(a>=0&&a<trackCount && (int)d.textWidth(basename(tracks[a]))>d.width()-8)draw();
  }else if(mode==FILE_BROWSER&&folderQueueActive&&active.load()>=0&&active.load()<trackCount){
   if((int)d.textWidth(basename(tracks[active.load()]))>d.width()-8)draw();
  }
 }
 if(millis()-lastBatteryPaint>=30000){lastBatteryPaint=millis();draw(false);}
 if(M5Cardputer.Keyboard.isChange()&&M5Cardputer.Keyboard.isPressed()&&millis()-lastKey>120){
  lastKey=millis();auto &k=M5Cardputer.Keyboard;
  // Direct physical keys: no Fn modifier required.
  // The colon-labelled key normally reports ';' without Fn/Shift.
  // Up/down are used in menus and browser only; genre shuffle has no list navigation.
  bool up=k.isKeyPressed(';')||k.isKeyPressed(':');
  bool down=k.isKeyPressed('.');
  bool left=k.isKeyPressed(',');
  bool right=k.isKeyPressed('/');
  bool stop=k.isKeyPressed(KEY_BACKSPACE);
  if(mode==LAUNCHER){
   if(left||right)launcherChoice=(launcherChoice%2==0)?launcherChoice+1:launcherChoice-1;
   else if(up||down)launcherChoice=(launcherChoice+2)%4;
   else if(k.isKeyPressed(KEY_ENTER)){
    if(launcherChoice==0){mode=HOME;menuSelection=0;}
    else if(launcherChoice==1){mode=SD_APP;beginSDExport();}
    else if(launcherChoice==2){waitForDecoderStop();mode=SEQUENCER;}
    else mode=DIAG_APP;
   }
   draw();
  }else if(mode==HOME){
   if(k.isKeyPressed('`')){mode=LAUNCHER;draw();}
   else if(up){menuSelection=(menuSelection+MENU_COUNT-1)%MENU_COUNT;keepMenuVisible();draw();}
   else if(down){menuSelection=(menuSelection+1)%MENU_COUNT;keepMenuVisible();draw();}
   else if(k.isKeyPressed(KEY_ENTER)){
    if(menuSelection<GENRE_COUNT)startCategory(menuSelection);
    else openBrowser();
   }
  }else if(mode==SEQUENCER){
   if(k.isKeyPressed('`')){stopSeq();mode=LAUNCHER;draw();}
   else if(left){seqCursor=(seqCursor+16)%17;draw();}
   else if(right){seqCursor=(seqCursor+1)%17;draw();}
   else if(up){seqChannel=(seqChannel+3)%4;draw();}
   else if(down){seqChannel=(seqChannel+1)%4;draw();}
   else if(k.isKeyPressed('w')){seqBpm=max(40,seqBpm-5);draw();}
   else if(k.isKeyPressed('s')){seqBpm=min(240,seqBpm+5);draw();}
   else if(k.isKeyPressed(' ')&&seqCursor>0){steps[seqChannel][seqCursor-1]=!steps[seqChannel][seqCursor-1];draw();}
   else if(k.isKeyPressed(KEY_ENTER)){
    if(seqCursor==0){scanSamples();mode=SAMPLE_BROWSER;}
    else {if(seqRunning)stopSeq();else {seqRunning=true;seqAudioEnabled=true;seqStep=0;seqLastTick=millis();fireSeqStep(0);}}
    draw();
   }
   else if(k.isKeyPressed('1')||k.isKeyPressed('2')||k.isKeyPressed('3')||k.isKeyPressed('4')){
    for(int i=0;i<4;i++)if(k.isKeyPressed('1'+i)){seqChannel=i;break;}
    seqCursor=0;scanSamples();mode=SAMPLE_BROWSER;draw();
   }
  }else if(mode==SAMPLE_BROWSER){
   if(k.isKeyPressed('`')){mode=SEQUENCER;draw();}
   else if(up&&sampleCount){sampleChoice=(sampleChoice+sampleCount-1)%sampleCount;draw();}
   else if(down&&sampleCount){sampleChoice=(sampleChoice+1)%sampleCount;draw();}
   else if(k.isKeyPressed(KEY_ENTER)&&sampleCount){
    String selected="/Samples/"+sampleNames[sampleChoice];
    if(loadSeqSample(seqChannel,selected))mode=SEQUENCER;
    draw();
   }
  }else if(mode==SD_APP){
   if(k.isKeyPressed('`')){
    // Manual release after Windows Eject. Some hosts do not send START_STOP.
    // Never depend on hostEjected to return to the launcher.
    // Also allow retry if the previous remount failed.
    bool ready=sdExported?endSDExport():remountLocalSD();
    if(ready){mode=LAUNCHER;draw();}
    else{sdExportError=true;draw();Serial.println("SD: remount failed; BACKTICK retries");}
   }
  }else if(mode==DIAG_APP){
   if(k.isKeyPressed('`')){mode=LAUNCHER;draw();}
  }else if(mode==FILE_BROWSER){
   if(k.isKeyPressed('`'))browserBack();
   else if(up){if(browserCount)browserSelection=(browserSelection+browserCount-1)%browserCount;draw();}
   else if(down){if(browserCount)browserSelection=(browserSelection+1)%browserCount;draw();}
   else if(k.isKeyPressed(KEY_ENTER)){
    if(folderQueueActive&&playing.load()&&browserCount&&active.load()>=0&&active.load()<trackCount&&browserPaths[browserSelection]==tracks[active.load()]){
     paused=!paused.load();draw();
    }else chooseBrowserEntry();
   }
   else if(stop&&folderQueueActive){stopTrack();draw();}
   else if(left&&folderQueueActive)advance(-1);
   else if(right&&folderQueueActive)advance(1);
  }else{
   if(k.isKeyPressed('`')){if(mode==FOLDER_PLAYER){if(waitForDecoderStop()){mode=FILE_BROWSER;browserPath=folderPlayingPath;scanBrowser();draw();}}else returnToMenu();}
   else if(k.isKeyPressed(KEY_ENTER)){if(playing.load()){paused=!paused.load();draw();}else if(trackCount>0){requestPlay(selection);}}
   else if(left)advance(-1);
   else if(right)advance(1);
   else if(stop){stopTrack();draw();}
  }
  if(k.isKeyPressed('=')){
   volume=min(10,volume+1);M5Cardputer.Speaker.setVolume(speakerVolume());
   volumeDirty=true;volumeChangedAt=millis();
   Serial.printf("VOL: %d/10 (%d/255)\n",volume,(int)speakerVolume());
  }else if(k.isKeyPressed('-')){
   volume=max(0,volume-1);M5Cardputer.Speaker.setVolume(speakerVolume());
   volumeDirty=true;volumeChangedAt=millis();
   Serial.printf("VOL: %d/10 (%d/255)\n",volume,(int)speakerVolume());
  }
 }
 if(mode==SEQUENCER&&seqRunning&&millis()-seqLastTick>=(uint32_t)(60000UL/(seqBpm*4))){
  seqLastTick=millis();seqStep=(seqStep+1)%16;fireSeqStep(seqStep);draw();
 }
 delay(1);
}
