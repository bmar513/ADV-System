ADV System r0.6 — WAV SEQUENCER EXPERIMENTAL

- Keeps r0.5 USB SD implementation unchanged.
- Centers launcher button labels.
- Sequencer header displays BPM; W lowers, S raises by 5 (40..240).
- Four 16-step channels, independent PCM voices mixed to speaker.
- WAV ONLY: 16-bit signed PCM, MONO, 16000 Hz, up to 3 seconds/sample.
  Other WAV encodings/rates are rejected with a screen error.
- /Samples browser now shows WAV only. Enter on channel button loads sample.
- ENTER on step starts/stops; stop resets to step 1.
- Tempo affects trigger frequency, NOT sample playback rate or pitch.
- Up to four voices mixed with saturation; re-trigger restarts same channel.
- Sample buffers loaded into PSRAM when available, then RAM fallback.
- No pattern persistence yet.

CAUTION: First implementation of audio mixer, NOT compiled or hardware-tested.
Speaker.playRaw streaming API compatibility and timing need real-hardware tests.
Keep v1.0 and r0.5 as fallbacks. Avoid SD app while sequencer is running.

Known working previous build environment: ESP32 3.2.1, ESP8266Audio
2.4.3 with compatibility workaround in included text file.
