# ADV System r1.1 — experimental six-button launcher

Based on ADV System r1.0 GitHub Package. Existing Music, Sequencer, USB SD, and DIAG retained.

## Launcher

MUSIC | SD
SEQUENCER | FLASH
NOTES | DIAG

## Notes

Plain text files stored in `/Notes` on SD. Enter inserts a newline. BACKTICK opens the Notes action menu (SAVE, OPEN, NEW, EXIT, CANCEL). `;` and `.` navigate lists; Enter selects. Existing notes can be opened and edited. New notes are named NOTE_0001.txt, etc. Maximum note length is 8 KB. Unsaved changes prevent opening, creating, or exiting until saved.

## FLASH — IMPORTANT LIMITATION

This build **only browses** `.bin` files in `/Firmware`. Installation is deliberately DISABLED. A regular Arduino OTA firmware update cannot guarantee RESET returns to ADV System: it normally boots the last selected app. Implementing the requested always-return-to-ADV behavior needs a verified persistent boot manager and partition strategy, plus tests with third-party binaries. Do NOT represent the browser as a working firmware installer. No partition changes are made.

## Build status

Source assembled and ZIP validated. NOT compiled against the user's Arduino environment or tested on hardware. Keep r1.0 as the tested fallback.
