ADV System r1.0 — final source package

Apps: Music, USB SD, 4-channel WAV sequencer, scrollable DIAG.

Maintenance changes from previous r1.0:
- Corrected outdated header/version comments.
- USB MSC raw-sector read/write callbacks now use the existing SD mutex with
  bounded wait and overflow-safe sector bounds checking.
- USB re-enumeration occurs after releasing the SD mutex, avoiding a possible
  deadlock if a USB callback runs during reconnection.
- BACKTICK export shutdown synchronizes with any in-progress MSC callback
  before relinquishing SD ownership.
- Logs sequencer task creation result.

Normal SD workflow: Windows safe eject, then BACKTICK on ADV.
The card is reinitialized and verified locally before returning to launcher.

IMPORTANT: This has NOT been compiled or hardware tested. The previous r0.9b
was the user-tested working basis. Validate all apps, especially Windows USB
write/eject/reenter, before replacing a working firmware or publishing.
For large transfers, compare SHA-256 hashes of a copied file and its return.

Build: consult AUDIOOUTPUTPDM_COMPATIBILITY_EDIT.txt.
