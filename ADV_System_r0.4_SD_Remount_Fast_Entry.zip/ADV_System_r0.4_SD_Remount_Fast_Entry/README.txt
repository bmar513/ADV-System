ADV System r0.4 — SD remount verification and fast entry

Changes relative to previous r0.4:
- BACKTICK still exits SD without requiring the Windows eject notification.
- On exit, removes USB MSC medium and retries local SD initialization up to
  four times. Checks that the root directory actually opens.
- If local remount fails, STAYS IN SD APP with an error; BACKTICK retries.
  This avoids silently entering Music with a nonfunctional SD filesystem.
- Fast SD entry avoids the redundant SD.end()/SD.begin() when the card is
  already locally mounted. Adds a short media-remove/reinsert transition.
- No extra lock on Music/Sequencer after a successful remount.

IMPORTANT: Always safely eject in Windows before BACKTICK. Never let the PC
and ADV access the card at the same time. The code cannot guarantee that the
host has flushed writes unless you eject properly.

The >60 second Windows initial mount delay is NOT proven resolved. Avoiding
an extra local SD initialization may help, but USB host enumeration or MSC
handshaking may be the actual bottleneck. Serial Monitor timing output is
included for follow-up diagnosis.

Other functionality from r0.4 retained. Sequencer audio and DIAG measurement
features remain unimplemented. This is NOT compiled or hardware tested.

ESP32 3.2.1 / ESP8266Audio 2.4.3 with one-line compatibility edit, see
included AUDIOOUTPUTPDM_COMPATIBILITY_EDIT.txt.
